<?php $this->load->view('header')?>

<body>
    
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <section class="container">
            <ul class="nav navbar-nav">
                    <li> <a target='_blank' href="<?php echo base_url(''); ?>" >Ver site</a> </li>
                    <li> <a href=" <?php echo base_url('fotos_config'); ?> ">Fotos</a> </li>
                    <li> <a href=" <?php echo base_url('setup/alterar'); ?> ">Configuração</a></li>
                    <li> <a href=" <?php echo base_url('setup/logout'); ?> ">Sair</a></li>
            </ul>
        </section>    
    </nav>
    
    <main>
    <div class="menuLateral">
        <ul class="opcoes">
            <li> <a href=" <?php echo base_url('fotos_config/cadastrar'); ?> ">Inserir</a> </li>
            <li> <a href=" <?php echo base_url('fotos_config/listar'); ?> ">Listar</a></li>
        </ul>
    </div>  
    
    <div class="fotosConfig">
        <h2 class="subtitulo"> <?php echo $h2; ?></h2>
        
        <?php 
            if($msg){
                echo '<div class="msg-aviso" style="max-width: 100%; width: 100%;">'.$msg.'</div>';
            }


            switch($tela):
                case 'listar':
        
                    if(isset($fotos) && sizeof($fotos) > 0){ ?>
                        <div >
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <th colspan="3" class="tabelaHead">Fotos</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <?php $count = 0; 
                                            
                                            foreach ($fotos as $foto):  ?>
                                            
                                                <td class="corpo" style="padding-left: 10%;">
                                                    
                                                    <?php 
                                                        echo $foto->nome; ?> &nbsp;
                                                    <?php echo anchor('fotos_config/editar/'.$foto->id, 'Editar'); ?> 
                                                    | <?php echo anchor('fotos_config/excluir/'.$foto->id, 'Excluir'); ?>
                                                    | <?php echo anchor('post/',/*.$foto->id, */'Ver', array('target' => '_blank')); ?> 
                                                    <img src="<?php echo base_url('uploads/'.$foto->foto);  ?>" alt="imagem <?php echo $foto->id; ?>" class="img-responsive"/> 
                                                </td>
                                            <?php $count = $count + 1; 
                                                           
                                                if($count == 2) { ?>
                                                    </tr>
                                                    <tr>    
                                            <?php   $count = 0;     
                                                } 
                                            endforeach; ?>
                                        </tr>
                                    </tbody>        
                                </table> 
                            </div> 
                        </div>    
                    <?php } else {
                            echo '<div class="msg-aviso">
                                    <p> Nenhuma foto cadastrada! </p>
                                 </div>';
                        }
                    break;
        
                case 'cadastrar':?>
        
                    <form action="" method="POST" enctype="multipart/form-data" onsubmit="return checkNome(this)" >
                        <label class="control-label" name="labelNome" for="nome">Nome da Imagem: </label>
                        <textarea class="form-control editorhtml" name="nome" required>
                            <?php if(isset($nome)){ 
                                    echo $nome; 
                                  } ?>
                        </textarea>
                        <label class="control-label" name= "labelImagem" for="imagem">Upload da imagem (thumbnail): </label>
                        <input type="text" class="form-control image-preview-filename" disabled="disabled" id="fileImage">
                        <div class="btn btn-default image-preview-input">
                            <span class="image-preview-input-title">
                                <input type="file" accept="image/png, image/jpeg, image/gif, image/jpg" name="imagem" id="imagem" onChange="selectorImage()" required>
                                <i class="fa fa-picture-o" aria-hidden="true"> Escolher imagem</i>
                            </span>   
                              
                        </div>
                        <br> <br>
                        <input type="submit" class="btn btn-primary env" name="enviar" value="Enviar">                          
                    </form>    
                    <?php 
                    break; 
        
                case 'editar': ?>
        
                    <form action="" method="POST" enctype="multipart/form-data" onsubmit="return checkNome(this)">
                        <label class="control-label" name="labelNome" for="nome">Nome da Imagem: </label>
                        <textarea class="form-control editorhtml" name="nome" required> 
                            <?php if(isset($fotos->nome)){ 
                                    echo $fotos->nome; 
                                  } ?>
                        </textarea>
                        <label class="control-label" name= "labelImagem" for="imagem">Upload da imagem (thumbnail): </label>
                        <input type="text" class="form-control image-preview-filename" disabled="disabled" id="fileImage">
                        <div class="btn btn-default image-preview-input">
                            <span class="image-preview-input-title">
                                <input type="file" accept="image/png, image/jpeg, image/gif, image/jpg" name="imagem" id="imagem" onChange="selectorImage()">
                                <i class="fa fa-picture-o" aria-hidden="true"> Escolher imagem</i>
                            </span>   
                        </div>
                        <br> <br>
                        <div id="excluirDiv">
                            <label class="control-label" name= "labelImagem" for="imagem">Imagem Atual: </label>
                            <img src=" <?php  echo base_url('uploads/'.$fotos->foto) ?>" max-width= "15%" max-heigth="15%" alt="imagem" class="img-reponsive"/> 
                            <input type="submit" class="btn btn-primary env" name="editar" value="editar" style="margin-left: 110%; margin-top:3.5%;">                          
                        </div>    
                    </form>    
                    <?php 
                    break;
                          
                case 'excluir':?>
        
                    <form action="" method="POST">
                        <label class="control-label" name="labelNome" for="nome">Nome da Imagem: </label>
                        <textarea class="form-control editorhtml" name="nome" required> 
                            <?php if(isset($fotos->nome)){ 
                                    echo $fotos->nome; 
                                  } ?>
                        </textarea>
                        <div id="excluirDiv">
                            <label class="control-label" name= "labelImagem" for="imagem">Imagem: </label>
                            <img src=" <?php  echo base_url('uploads/'.$fotos->foto) ?>" max-width= "15%" max-heigth="15%" alt="imagem" class="img-reponsive"/> 
                            <input type="submit" class="btn btn-primary env" name="excluir" value="Excluir" style="margin-left: 110%; margin-top:3.5%;">                          
                        </div>    
                    </form>    
                    <?php 
                    break;
        
            endswitch;
        ?>
        

        </div>            
    </main>
    <script> $(".editorhtml").jqte();</script>
</body>

<?php $this->load->view('footer')?>