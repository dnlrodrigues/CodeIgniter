<?php $this->load->view('header')?>

<body>
    <h2 class="subtitulo"> <?php echo $h2; ?></h2>
    <?php 
        if($msg){
            echo '<div class="msg-aviso" style="margin-left: 47%; margin-rigth:0;" >'.$msg.'</div>';
        }
    ?>  
    <div class="container">
        <form action="" onsubmit="return checkForm(this)" method="POST" class="cadastro">
            <div class="form">
                <label class="label-control" for="login">Nome do Usuário:</label>
                <input class="form-control" type="text" name= "login" required autofocus>
                <label class="label-control" for="email">Email:</label>
                <input class="form-control" type="email" name="email" required>                
                <label class="label-control" for="passwords">Senha:</label>
                <input class="form-control" type="password" name="password" required>
                <label class="label-control" for="repitPassword">Repita a Senha:</label>
                <input class="form-control" type="password" name="repitPassword" required> <br> <br>
                <input class="btn btn-info enviar" type="submit" name="enviar" value="Enviar">
            </div>    
        </form>
    </div>

<?php /*var_dump($_SESSION) serve para printar as informações que estão armazenadas na session
        session ´´e um espaço reservado no navegador para armazenar informações que o usuário pode precisar durante a nagevação, por exemplo login, carrinho isso em conjunto com o banco*/
    $this->load->view('rodape')?>