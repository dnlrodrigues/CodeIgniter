<?php $this->load->view('header')?>

<body>  
    <div class="container">
        <div>
            
            <?php 
                if($msg){
                    echo '<div class="msg-aviso">'.$msg.'</div>';
                }
            ?>            
            <img src=" <?php echo base_url('assets/img/user.png')?> " class="img-responsive user" alt="usuario"/>
            
            <form action="" method="POST" onsubmit="return loginPassword(this)" method="post">
                <div class="form logar">
                    <label class="label-control" for="user">Usuário:</label>
                    <input class="form-control" type="text" name= "user" required autofocus>              
                    <label class="label-control" for="passwords">Senha:</label>
                    <input class="form-control" type="password" name="password" required> <br> <br>
                    <input class="btn btn-primary logar" type="submit" name="logar" value="Login">
                </div>    
            </form>
        </div> 
    </div>

<?php $this->load->view('rodape')?>