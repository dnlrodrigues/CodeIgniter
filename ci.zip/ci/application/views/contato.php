<?php $this->load->view('cabecalho')?>

    <div>
        <section class="contato">
            <div class="mapaContato">
                <h3>Localização</h3>
                <img class=" <?php echo base_url('assets/img/img2.jpg') ?>" alt="mapa"/> <br>
                <ul>
                    <li>Rua Machado de Assis 121</li>
                    <li>Bairro Moinhos</li>
                    <li>Possibilândia - UF</li>
                </ul>
                <h3>Contato direto</h3>
                <ul>
                    <li>Fone: <span style="font-weight: bold">(00) 9999-9999</span></li>
                    <li>Email: <span style="font-weight: bold">contato@viagemcorporation.com</span></li>
                    <li>Skype: <span style="font-weight: bold">login.skype</span></li>
                </ul>
            </div>
            <div class="formContato">
                <h2>Envie uma menagem</h2>
                <?php
                    if($formerror):
                        echo '<p>'.$formerror.'</p>';
                    endif;
                    echo form_open('pagina/contato'); /*chamando o helper de formularáio e dentro dele os parâmentro 1º action(função) que vai executar o comando do formulario, neste exemplo é possível deixa 'pagina/contato ou deixar em  branco' outros a tributos que podem ser inseridos é classes*/
                    echo form_label('Seu nome: ', 'nome'); /*para gerar o label, parametros: 1º nome que será apresentado na label, nome da referencia da label com  o input, $atributo quando houver necessidade*/
                    echo form_input('nome', set_value('nome')); /*para gerar um input tendo como parâmetro: 1º name do input, 2ºvalue do  input, 3º $attributes do input, a propriedade set_value(nome do input) serve para que quando o clicado no submit o campo input recuperará o valor inserido, mesmo  que já tenha sido enviado aquela informação*/
                    echo form_label('Seu email: ', 'email');
                    echo form_input('email', set_value('email'));
                    echo form_label('Assunto: ', 'assunto');
                    echo form_input('assunto');
                    echo form_label('Mensagem: ', 'mensagem');
                    echo form_textarea('mensagem');
                    echo form_submit('enviar','Enviar', array('class' => 'botao')); /*função do botão submit sendo os parâmetros: 1ºnome do botão, 2º value do botão, 3ºarray para  poder chamar as classes de estilização do botão, sendo ela 'botao'*/
                    echo form_close();
                ?>                
         <!--       <form action="">
                    <div class="form">
                        <label class="label-control" for="nome">Seu nome:</label>
                        <input class="form-control" type="text" name= nome id="nome"/>
                        <label class="label-control" for="email">Seu email:</label>
                        <input class="form-control" type="text" name="email" id="email">                
                        <label class="label-control" for="assunto">Assunto:</label>
                        <input class="form-control" type="text" name="assunto" id="assunto">
                        <label class="label-control" for="mensagem">Mensagem:</label> <br>
                        <textarea name="mensagem" id="mensagem">Mensagem:</textarea> <br> <br>
                        <button class="btn btn-info" name="enviar">Enviar</button>
                    </div>    
                </form>-->
            </div>
        </section>
    





    </div>

<?php $this->load->view('rodape')?>