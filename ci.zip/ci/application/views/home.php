<?php $this->load->view('cabecalho')?>

<body class="home">

    <nav class="navbar navbar-inverse navbar-fixed-top">
        <section class="container">
            <div class="navbar-header"> 
                <a class="navbar-brand" href="<?php base_url(); ?>">Home</a>
            </div>
            <div> 
                <ul class="nav navbar-nav">
                    <li> <a href="<?php echo base_url('sobre'); ?>" >Sobre a Empresa</a> </li>
                    <li> <a href="<?php echo base_url('fotos'); ?>">Fotos</a> </li>
                    <li> <a href=" <?php echo base_url('contato'); ?> ">Contato</a></li>
                    <li> <button class="btn btn-primary login" onclick="location.href='<?php echo base_url('setup') ?>'">Setup</button></li>
                </ul>
            </div>
        </section>    
    </nav>
    <div class="container">
    <article>
    <h2 class="h2Home">Viagens</h2>
        <img src=" <?php echo base_url('assets/img/home.jpg') ?> " alt="paisagem" title="praia" class="img-reponsive">  
        <p id="refImg">Uma viagem (do latim "viaticu", pelo provençal "viatge") é o movimento de pessoas entre locais relativamente distantes, com qualquer propósito e duração, e utilizando ou não qualquer meio de transporte (público ou privado). O percurso pode ser feito por mar, terra ou ar. Também se entende como viagem todo um período de deslocações com estadias mais ou menos longas em alguns destinos.</p>    
        <p>Uma viagem pode ser realizada com fins recreativos, para visitar amigos ou família, para realizar negócios ou para trabalhar (diariamente fazendo o percurso). No entanto, também se viaja por outras razões: por motivos de saúde, migrações, fuga a guerras, etc. A viagem pode ser local, regional, nacional (doméstica) ou internacional. Quando realizada a nível internacional, normalmente, as autoridades exigem um passaporte ou visto. </p>
        <br>
        <p>A viagem para fora do entorno habitual do indivíduo, com duração inferior a um ano, e cujo propósito principal não é o exercício de atividade remunerada por entidades do local visitado, é chamada de viagem turística.[1]</p>
        <br>
        <p>O automóvel foi o grande impulsionador das viagens privadas e para fins recreativos. A liberdade que trouxe às pessoas e a rapidez com que se passaram a cobrir as distâncias foi um dos grandes motivos para deslocações e troca de experiências e culturas. Mais tarde, o avião com bilhetes a preços acessíveis viria a facilitar ainda mais as viagens a uma escala global.</p>
        <br>
        <p>Hoje em dia, as viagens e o turismo são um dos mais importantes negócios a nível mundial, o que fez aumentar exponencialmente o número de agências de viagem, cuja função é a de reservar bilhetes de avião, hotel, automóvel de aluguer no destino, etc. O internauta pode agora, também, tratar de todos os procedimentos através da internet, incluindo fazer reservas online, trocar de casa com outros viajantes durante determinado período, ler artigos de outros viajantes em blogs, ou "fotoviajar" sem sair de casa através das experiências de outros.</p>    
    </article>
    
    </div>
    
</body>
     <nav class="navbar navbar-inverse navbar-fixed-bottom">
         <div class="container">
            <p class=" footer ">Contato: +55 (44) 99999-9999 São Paulo - SP, Brasil</p>
         </div>
    </nav>

<?php $this->load->view('rodape')?>