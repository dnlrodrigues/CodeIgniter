<?php $this->load->view('cabecalho')?>

<body>
        <?php if(isset($fotos) && sizeof($fotos) > 0){ ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <th colspan="3" class="tabelaHead">Fotos</th>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $count = 0; 
                                foreach ($fotos as $foto):  ?>        
                                    <td class="corpo" style="padding: 1% 10%;">            
                                        <?php 
                                            echo $foto->nome;?> <br>
                                            <img src="<?php echo base_url('uploads/'.$foto->foto);  ?>" alt="imagem" class="img-responsive" /> 
                                    </td>
                                    <?php $count = $count + 1;                        
                                        if($count == 3) { ?>
                                            </tr>
                                            <tr>    
                                            <?php  $count = 0;     
                                                } 
                                        endforeach; ?>
                        </tr>

                    </tbody>        
                </table>         
            </div> 
        <?php } else {
                        echo '<div class="msg-aviso">
                                <p> Nenhuma foto cadastrada! </p>
                             </div>';
                    } ?>
</body>    

<?php $this->load->view('rodape')?>