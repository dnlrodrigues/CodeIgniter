<?php $this->load->view('cabecalho')?>

<body class="empresa">
<div class="sobre">
    <h1 class="hSobre">Nossa História</h1>
    
    <p>Tudo começou a partir de uma ideia de alcançar novos mundo, ultrapassar horizontes e em busca deste destino desconhecido a Viagem Corparation vive em buscar de trazer experiências a seus clientes exuberantes algo não visto. Nosso diferencial está em ver aquilo que os outros não conseguem, enxergar perspectiva onde outros vem derrotas.</p>
    <p><span class="paragrafo">Nossa missão</span> é que nossos clientes vivem um mundo novo de forma que nunca mais vejam o mundo como era antes</p>
    <p><span class="paragrafo">Nossa visão</span> é alçancar toda a fronteira da América</p>
    <ul>
       <h3 class="hSobre">Nossos valores são: </h3>
       <li>Imaginação</li>
       <li>Visão</li>    
       <li>Respeito</li>  
       <li>Paixão</li>
       <li>Força de Vontade</li>    
     </ul>  
</div>    
</body>    

<?php $this->load->view('rodape')?>