<?php $this->load->view('header')?>

<body>
    
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <section class="container">
            <ul class="nav navbar-nav">
                    <li> <a target='_blank' href="<?php echo base_url(''); ?>" >Ver site</a> </li>
                    <li> <a href=" <?php echo base_url('fotos_config'); ?> ">Fotos</a> </li>
                    <li> <a href=" <?php echo base_url('setup/alterar'); ?> ">Configuração</a></li>
                    <li> <a href=" <?php echo base_url('setup/logout'); ?> ">Sair</a></li>
            </ul>
        </section>    
    </nav>
    
    <h2 class="subtitulo"> <?php echo $h2; ?></h2>
    <?php 
        if($msg){
            echo '<div class="msg-aviso" style="margin-left: 47%; margin-rigth:0;" >'.$msg.'</div>';
        }
    ?>
    <div class="container">
        <form action="" onsubmit="return alterPassword(this)" method="POST" class="cadastro">
            <div class="form">
                <label class="label-control" for="login">Nome do Usuário:</label>
                <input class="form-control" type="text" name= "login" autofocus  value=" <?php echo $login; ?> " required >
                <label class="label-control" for="email">Email:</label>
                <input class="form-control" type="email" name="email" value=" <?php echo $email; ?> "  required>                
                <label class="label-control" for="passwords">Senha:</label>
                <input class="form-control" type="password" name="password" placeholder="Deixe em branco para não alterar">
                <label class="label-control" for="repitPassword">Repita a Senha:</label>
                <input class="form-control" type="password" name="repitPassword" placeholder="Deixe em branco para não alterar"> <br> <br>
                <input class="btn btn-info enviar" type="submit" name="enviar" value="Enviar">
            </div>    
        </form>
    </div>

<?php $this->load->view('footer')?>