<html lang="pt-br">
<head>
    <title> <?php echo $titulo; ?></title>
    <meta charset="utf-8">
    <meta name="description" content="My site in PHP with CI">
    <meta name="author" content="Daniela F.R.">
    <meta name="keywords" content="PHP, CodIgniter">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/> 
    <link rel="stylesheet" href="<?php echo base_url('assets/css/site.css')?>"/>
    <script src=" <?php echo base_url('assets/js/javascript.js')?> "></script>
    
</head>