<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class Fotos_model extends CI_Model{
    
    function __construct(){
        parent::__construct();
    }   
    
    public function salvar($dados){
        
        if(isset($dados['id']) && $dados['id'] > 0){
            $this->db->where('id', $dados['id']);
            unset($dados['id']); #deixa o id de fora da atualização uam vez que é uma chave primária e não pode ser atualizada, na query ele fica de fora
            $this->db->update('fotos', $dados);
            return $this->db->affected_rows();
        } else {
            $this->db->insert('fotos', $dados);
            return $this->db->insert_id();
        }
        
    }
    
    public function get($limit=0, $offset=0 ){
        if($limit == 0){
            $this -> db -> order_by('id'); /*caso queira incluir a ordenação desc é só colocar uma vírgula e desc */
            $query = $this -> db -> get ('fotos');
            
            if($query->num_rows()>0){
                return $query-> result();
            } else {
                return null;
            }
            
        } else{
            $this -> db -> order_by('id'); /*caso queira incluir a ordenação desc é só colocar uma vírgula e desc */
            $query = $this -> db -> get ('fotos', $limit, $offset);
            
            if($query->num_rows()>0){
                return $query-> result();
            } else {
                return null;
            }
            
        }
        
    }
    
    public function get_single($id=0){
        $this->db-> where('id', $id);
        $query = $this->db->get('fotos');
        
        if($query->num_rows() == 1){
            $row = $query -> row();
            return $row;    
        } else {
            return NULL;
        }
        
    }
    
    public function excluir($id=0){
        $this->db->where('id', $id);
        $this->db->delete('fotos'); /*nome da table em parenteses*/
        return $this->db->affected_rows();
    }
    
    
}