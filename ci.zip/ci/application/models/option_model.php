<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class Option_model extends CI_Model{
    
    function __construct(){
        parent::__construct();
    }   
    
    public function get_option($option_name){
        $this->db->where('option_name', $option_name); /*query fazendo o select, select option_name from  options where optionn_name = $options_name, primeiro parametro nome do campo da tabela, segunda variável a ser comparadas com os registros naquele campo*/
        $query = $this -> db -> get ('options', 1); /*limita o resultado 1 registro, primeiro parametro nome da tabela, segundo o números de registro as ser retornado*/
        if($query -> num_rows() == 1){ /*retorno da query, se acaso retorne uma linha*/
            $row = $query -> row(); /*a variável row recebe a linha da query*/
            return $row -> option_value; /*a variavel row está acessando o campo option_value*/
        } else {
            return null;
        } 
    }
    
    public function update_option($option_name, $option_value){
        $this-> db -> where('option_name', $option_name);
        $query = $this -> db -> get ('options',1);
        /*echo $this -> db -> last_query()  apresenta o código da query*/
        if ($query -> num_rows() == 1){
            $this -> db -> set('option_value', $option_value);
            $this -> db -> where ('option_name', $option_name);
            $this -> db -> update('options');
            return $this -> db -> affected_rows();
            /*numeros de linhas afetadas, ou seja, alteradas affected_rows()*/
        } else {
            $dados = array(
                'option_name' => $option_name,
                'option_value' => $option_value
            );
            $this->db-> insert('options', $dados);
            return $this-> db -> insert_id();
            /*o method insert_id recupera a última id inserida no banco, o method insert inseri valores na tabela e affected_rows retorna quantas linhas foram alteradas*/ 
        }
    }        
        
    
    
}