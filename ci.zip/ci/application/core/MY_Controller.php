<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class MY_Controller extends CI_Controller{
    
    function __construct(){
        parent::__construct();
        $this -> load -> library('session');
    }
    
    public function set_msg($msg){
        $this -> session -> set_userdata('aviso', $msg);
    }
    
    public function get_msg(){
        $aviso =  $this -> session -> userdata('aviso');
        $this -> session -> unset_userdata('aviso');
        return $aviso;
    }

    public function verifica_login(){
        $control = & get_instance();
        if($control -> session -> userdata('logged') != TRUE):
           $control -> set_msg('<p>Acesso restrito! Faça seu login para continuar.</p>');
           redirect('setup/login', 'refresh');
        endif;
    }
    
    public function config_upload($path='./uploads/', $types='jpg|png|jpeg|gif', $size=512){
        $config['upload_path'] = $path;
        $config['allowed_types'] = $types;
        $config['max_size'] = $size;
        return $config;
    }
    
    /*salva o html no banco, já confidicando ele*/
    function to_bd($string=NULL){
        return htmlentities($string);
    }
    
    /*retorna o html do banco decoficando ele*/
    function to_html($string=NULL){
        return html_entity_decode($string);
    }
    
}