<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class Pagina extends CI_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->helper('url'); /*é possivel carregar no controle inteiro ou na função*/
        $this->load->model('fotos_model', 'fotos');
    }
    
    public function index(){
        $dados['titulo'] = 'My site in PHP with CI';
        $this->load->view('home', $dados);
    }
    
     public function sobre(){
        $dados['titulo'] = 'Sobre - My site in PHP with CI';
        $this->load->view('sobre', $dados);
    }
    
     public function fotos(){
        $dados['titulo'] = 'Fotos - My site in PHP with CI';
        
        $imagens = $this->fotos->get();
        $dados['fotos'] = $imagens;
        
        if (isset($imagens)){
            foreach ($imagens as $imagem):
                $imagem->nome = $this->to_html($imagem->nome);
            endforeach;
        }  
         
        $this->load->view('fotos', $dados);
    }
    
    function to_html($string=NULL){
        return html_entity_decode($string);
    }
    
     public function contato(){
        $this->load->helper('form'); /*carregando o helper form*/
        $this->load->library(array('form_validation', 'email')); /*carregando a biblioteca de form_validation e do email*/
        //regras de validação do formulário
        $this->form_validation->set_rules('nome', 'Nome', 'trim|required'); /*seta as regras de validação de cada um dos campos do fomulario sendo a disposição dos parâmetros, 1ºnome do campo, 2º nome do campo que será apresentado na tela quando ocorrer um erro, 3º serve para colocar as regras de valições,podendo ser mais de uma separada por barra vertical e é possível colocar funções personalizadas ou nativas do php */
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('assunto', 'Assunto', 'trim|required');
        $this->form_validation->set_rules('mensagem', 'Mensagem', 'trim|required');
        //é possível fazer o if com : ou {}
        if($this->form_validation->run() == FALSE):
            $dados['formerror'] = validation_errors();
        else:
            $dados_form = $this -> input ->post(); /*recupera todos os dados do post*/
            $this->email->from($dados_form['email'], $dados_form['nome']); /*insere os dados recuperados dentro dos campos do e-mail*/
            $this->email->to('contato@viagemcorporation.com.br');
            $this->email->subject($dados_form['assunto']);
            $this->email->message($dados_form['mensagem']);    
     /*       if($this->email->send()):
                $dados['formerror'] = 'Email enviado com sucesso!';
            else: 
                $dados['formerror'] = 'Email não pode ser enviado, favor tente mais tarde';
            endif;*/
    //      print_r($dados_form); imprime os dados do  input post;
            $dados['formerror'] = 'Campos validados com sucesso';
        endif; 
        $dados['titulo'] = 'Fale comigo - My site in PHP with CI';
        $this->load->view('contato', $dados);
    }
    
     public function login(){
        $dados['titulo'] = 'Login - My site in PHP with CI';
        $this->load->view('login', $dados);
    }    
}