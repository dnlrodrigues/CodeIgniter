<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class Setup extends MY_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->model('option_model', 'option'); /*apelido option para model "option_model"*/ 
    }
    
    public function index(){
        if($this->option->get_option('setup_executado') == 1){
            redirect('setup/login', 'refresh'); /*nome do controller / página php que será redirecionada, ou seja, o nome da regra a ser aplicada dentro do controller*/
        } else{
            redirect ('setup/newAdmin', 'refresh');
        }
    }
    
    public function newAdmin(){
        if($this->option->get_option('setup_executado') == 1){
            redirect('login', 'refresh');
        } 
                
        if (array_key_exists('enviar', $_POST)){
            
            $dados_form = $this -> input ->post(); // está pegando os dados do input pelo post
            $this->load->helper('form');
            $this->load->library(array('form_validation'), 'email');
            
            $this->form_validation->set_rules('login', 'Usuário', 'trim|required|min_length[7]');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Senha', 'trim|required|min_length[6]|regex_match[/[A-Za-z0-9^\w+$]/]');
            $this->form_validation->set_rules('repitPassword', 'Repita a Senha', 'trim|required|matches[password]');
        
            if($this->form_validation->run() == FALSE){
                
                if(validation_errors()){
                    $this-> set_msg(validation_errors());
                    redirect('setup/newAdmin', 'refresh');
                }
                
            } else {
                $this -> option -> update_option ('user_login', $dados_form['login']);// primeiro parâmetro serve para criar uma variavel e o segundo o valor que vai ser inserido na variavel
                $this -> option -> update_option ('user_email', $dados_form['email']);
                $this -> option -> update_option ('user_password', password_hash ($dados_form['password'], PASSWORD_DEFAULT)); /*a função paswword_hash é uma função do php para criptografar a senha sendo que primeiro é passado a variável a ser criptografada e depois o tipo de codificação*/

                $inserido = $this->option->update_option('setup_executado', 1);      

                if($inserido){   
                    $this -> set_msg('<p style="color: green;">Administrador cadastrado!</p>');
                    redirect('setup/login', 'refresh');  
                } else {
                    $this -> set_msg('<p style="color: green;">Falha ao cadastrar o Administrador!</p>');
                    redirect('setup/newAdmin', 'refresh');
                }
                
            }
        }
        
        $dados['titulo'] = 'Administrador - Setup';
        $dados['h2'] = 'Cadastro';
        $dados['msg'] = $this -> get_msg();
        $this->load->view('newAdmin', $dados); /*nome da página php, array*/
        
    }
    
    public function login(){
        if($this->option->get_option('setup_executado') != 1){
           redirect('setup/newAdmin', 'refresh');
        }
             
        if(array_key_exists('logar', $_POST)){
            $dados_form = $this -> input -> post(); /*array com os dados do formulários via post*/
            
            if($this->option->get_option('user_login') == $dados_form['user']){ //retornando dados do banco e comparando com o formulário, em primeiro passada o dado do banco e segundo o campo do form

                if(password_verify($dados_form['password'], $this->option->get_option('user_password'))){ /*retornando a senha e comparando com o formulário através da função password_verify do php, no primeiro parametro passa o dado do campo, em seundo o campo do banco*/
                    $this -> session -> set_userdata('logged', TRUE); /*armazenando informações na sessão*/
                    $this -> session -> set_userdata('user_login', $dados_form['user']);
                    $this -> session -> set_userdata('user_email', $this->option->get_option('user_email'));
                    redirect('setup/alterar', 'refresh');
                } else{ 
                    $this -> set_msg('<p>Senha incorreta!</p>');
                    redirect('setup/login', 'refresh'); 
                }
            } else {
                $this -> set_msg('<p>Usuário Inexistente! </p>');
                redirect('setup/login', 'refresh'); 
            }
        }
               
        $dados['titulo'] = 'Login - Setup';
        $dados['msg'] = $this -> get_msg();
        $this -> load -> view('login', $dados);
        
    }
    
    public function alterar(){
        
        $this -> verifica_login();
        
        $dados['login'] = $this->option->get_option('user_login');
        $dados['email'] = $this->option->get_option('user_email');
                
        $this->load->helper('form');
        $this->load->library(array('form_validation'), 'email');
        
        $this->form_validation->set_rules('login', 'Usuário', 'trim|required|min_length[7]');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Senha', 'trim|min_length[6]|regex_match[/[A-Za-z0-9^\w+$]/]');
        
        if(isset($_POST['password']) && $_POST['password'] != ''){
            $this->form_validation->set_rules('repitPassword', 'Repita a Senha', 'trim|required|matches[password]');
        }
        
        if($this->form_validation->run() == FALSE){
        
            if(validation_errors()){
                $this-> set_msg(validation_errors());
                redirect('setup/alterar', 'refresh');
            }
                
        } else {        
            $dados_form = $this->input->post();
            $alterado['login'] = $this -> option -> update_option ('user_login', $dados_form['login']);
            $alterado['email'] = $this -> option -> update_option ('user_email', $dados_form['email']);
            
            if (isset($dados_form['password']) && $dados_form['password'] != ''){
                $alterado['senha'] = $this -> option -> update_option ('user_password', password_hash ($dados_form['password'], PASSWORD_DEFAULT));
            }
            
            
            if(($alterado['login'] >0) || ($alterado['email'] > 0) || ($alterado['senha'] > 0)){
               $this -> set_msg('<p style="color: green;">Dados alterados com sucesso!</p>');
                redirect('setup/alterar', 'refresh');
            } else {
                $this -> set_msg('<p>Falha ao alterar os dados!</p>');
                redirect('setup/alterar', 'refresh');
            }
        
        }
        
        $dados['titulo'] = 'Configuração do sistema';
        $dados['h2'] = 'Alteração do sistema';
        $dados['msg'] = $this -> get_msg();
        $this -> load -> view('configuracao', $dados);
        
    }
    
    public function logout(){
        $this->session->unset_userdata('logged');
        $this->session->unset_userdata('user_login');
        $this->session->unset_userdata('user_email');
        $this->set_msg('<p>Você saiu do sistema!<p>');
        redirect('setup/login', 'refresh');
    }
   
    
}
