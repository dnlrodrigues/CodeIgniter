<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');

class Fotos_config extends MY_Controller{
    
    function __construct(){
        parent::__construct();
        $this -> load -> library('form_validation');
        $this->load->model('option_model', 'option');
        $this->load->model('fotos_model', 'fotos');
    }
    
    public function index(){
        redirect('fotos_config/listar', 'refresh');
    }
    
    public function listar(){
        $this -> verifica_login();
        
        $dados['titulo'] = 'Listagem de Fotos - Setup';
        $dados['h2'] = 'Listagem de Fotos';
        $dados['tela'] = 'listar';
        $dados['msg'] = $this -> get_msg();
        
        $imagens = $this->fotos->get();
        $dados['fotos'] = $imagens;
        
        if (isset($imagens)){
            foreach ($imagens as $imagem):
                $imagem->nome = $this->to_html($imagem->nome);
            endforeach;
        }
        $this -> load -> view('fotos_configuracao', $dados);
    }
    
     public function cadastrar(){
        $this -> verifica_login();
        
        $this->load->library('upload', $this->config_upload());          
         
        if (array_key_exists('enviar', $_POST)){
            
            $this->form_validation->set_rules('nome', 'Nome', 'trim|required|max_length[150]|min_length[3]');
            
            if ($this->form_validation->run() == FALSE){
                
                if(validation_errors()){
                    $this->set_msg(validation_errors());
                    $dados['nome'] = $this->to_html($_POST['nome']);
                }
                
            } else {
                
                if($this->upload->do_upload('imagem')){
                    $dados_upload = $this->upload->data();

                    $dados_insert['nome'] = $this->to_bd($_POST['nome']); /*chamando a função para codificar o  html para salvar no banco*/
                    $dados_insert['foto'] = $dados_upload['file_name']; /*recebendo informações para salvar o nome do arquivo no banco, sendo 1º parametro o nome do campo na tabela e 2º o nome do formulario*/ 

                    if ($id = $this->fotos->salvar($dados_insert)){
                        $msg = '<p style="color: green"> Arquivo carregado com sucesso! </p>';
                        $this->set_msg($msg);
                        redirect('fotos_config/editar/'.$id, 'refresh');
                    } else {
                        $msg = '<p> Arquivo não pode ser salvo!.</p>';
                        $this->set_msg($msg);
                        $dados['nome'] = $this->to_html($_POST['nome']);
                    }

                } else{
                    $msg = $this->upload->display_errors();
                    $msg .= '<p> São permitidos arquivos JPG/PNG/JPEG/GIF de até 512KB.</p>';
                    $this->set_msg($msg);
                }
                
            }
        } 
         
        $dados['titulo'] = 'Cadastro de Fotos - Setup';
        $dados['h2'] = 'Cadastro de Fotos';
        $dados['tela'] = 'cadastrar'; 
        $dados['msg'] = $this -> get_msg();
        $this -> load -> view('fotos_configuracao', $dados);
    }
    
    
    public function excluir(){
        $this->verifica_login();
        
        $id = $this->uri->segment(3); /*segment(3) significa que é a terceira posição da uris*/
        
        if($id > 0){ /*é possível fazer direto a verificação if(($id=$this->uri->segment(3))>0) */
            
            if($foto = $this->fotos->get_single($id)){
                $dados['fotos'] = $foto;
            } else{
                $this->set_msg('<p style="margin-left: -3%;">Foto inexistente! Escolha uma foto para excluir.</p>');
                redirect('fotos_config/listar', 'refresh');
            }
            
        } else {
            $this->set_msg('<p>Você deve escolher uma notícia para excluir!</p>');
            redirect('fotos_config', 'refresh');
        }
        
        $dados['titulo'] = 'Excluir de Fotos - Setup';
        $dados['h2'] = 'Excluir de Fotos';
        $dados['tela'] = 'excluir';
        $dados['msg'] = $this -> get_msg();
        $this -> load -> view('fotos_configuracao', $dados);
        
        
        if(array_key_exists('excluir', $_POST)){
               
            $imagem = 'uploads/'.$foto->foto;
            
            //model fotos função excluir
            if($this->fotos->excluir($id)){
                unlink($imagem); //excluir foto da pasta, após excluir id do banco;
                $this->set_msg='<p style="color: green">Foto excluída com sucesso!</p>';
                redirect('fotos_config/listar', 'refresh');
            } else {
                $this->set_msg='<p>Erro! Nenhuma foto foi excluída!</p>';
            }
                  
        }
                
    }
    
    public function editar(){
        $this->verifica_login();
        
        $id = $this->uri->segment(3); /*segment(3) significa que é a terceira posição da uris*/
        
        if($id > 0){ /*é possível fazer direto a verificação if(($id=$this->uri->segment(3))>0) */
            
            if($foto = $this->fotos->get_single($id)){
                $dados['fotos'] = $foto;
                $dados_update['id'] = $foto->id;
            } else{
                $this->set_msg('<p style="margin-left: -3%;">Foto inexistente! Escolha uma foto para editar.</p>');
                redirect('fotos_config/listar', 'refresh');
            }
            
        } else {
            $this->set_msg('<p>Você deve escolher uma notícia para editar!</p>');
            redirect('fotos_config', 'refresh');
        }
        
        
        if(array_key_exists('editar', $_POST)){
            
            $this->form_validation->set_rules('nome', 'Nome', 'trim|required|max_length[150]|min_length[3]');
            
            if ($this->form_validation->run() == FALSE){
                
                if(validation_errors()){
                    $this->set_msg(validation_errors());
                    $dados['nome'] = $this->to_html($_POST['nome']);
                }
                
            } else {
                $this->load->library('upload', $this->config_upload());
                 
                
                if(isset($_FILES['imagem']) && $_FILES['imagem']['name'] != ''){ //verificando se exite o arquivo com name imagem no post e arquivo com name imagem e name nome da imagem 
                
                    if($this->upload->do_upload('imagem')){
                        $imagem_antiga = 'uploads/'.$foto->foto;
                        $dados_upload = $this->upload->data();
                        $dados_update['nome'] = $this->to_bd($_POST['nome']);
                        $dados_update['foto'] = $dados_upload['file_name']; /*dados (variavel) _ update(função no banco) ['campo do banco']*/
                        
                        
                        if($this->fotos->salvar($dados_update)){
                            unlink($imagem_antiga);
                            $this->set_msg('<p style="color: green;">Foto alterada com sucesso!</p>');
                            $dados['fotos']->foto = $dados_update['foto'];
                        } else {
                            $this->set_msg('<p>Erro! Nenhuma alteração por ser concluída, tente novamente.</p>');
                        }
                        
                        
                    } else {
                        $msg = $this->upload->display_errors();
                        $msg .= '<p> São permitidos arquivos JPG/PNG/JPEG/GIF de até 512KB.</p>';
                        $this->set_msg($msg);
                    }
                    
                    
                } else {
                    $dados_update['nome'] = $this->to_bd($_POST['nome']);
                    if($this->fotos->salvar($dados_update)){
                        $this->set_msg('<p style="color: green;">Foto alterada com sucesso!</p>');
                    } else {
                        $this->set_msg('<p>Erro! Nenhuma alteração por ser concluída, tente novamente.</p>');
                    }
                      
                    
                }
                   
            }
                                  
        }
        
        $dados['titulo'] = 'Edição de Fotos - Setup';
        $dados['h2'] = 'Edição de Fotos';
        $dados['tela'] = 'editar'; 
        $dados['msg'] = $this -> get_msg();
        $this -> load -> view('fotos_configuracao', $dados);
        
        
        
                
    }
    
    
}