function checkForm(form) {
        var passRegex1 = /[A-Za-z]/;
        var passRegex2 = /[0-9]/;
        var passRegex3 = /^\w+$/;
        
        if(form.login.value != "" && passRegex1.test(form.login.value)){
            
            if(form.login.value.length < 7){
                alert("O usuário deve conter no mínimo 7 caracteres");
                form.login.focus;
                return false;
            }
            
        } else {
            alert("Usuário com caracteres inválido! O campo permite apenas letras.")
            form.login.focus;
            return false;
        }
    
        if(form.password.value != "" && form.password.value == form.repitPassword.value){
            if(form.password.value.length < 6){
                alert("A senha deve conter mais de 6 caracter!");
                form.password.focus;
                return false;
            } 
        } else {
            alert("Senha inválida!")
            form.password.focus;
            return false;
        }
        
        if(!passRegex1.test(form.password.value) && !passRegex2.test(form.password.value) && passRegex3.test(form.password.value)){
            alert("Senha incorreta");
            form.password.focus();
            return false;
        }
    
}

function loginForm(form) {    
        
        if(form.login.value != ""){
            
            if(form.login.value.length < 7){
                alert("O usuário deve conter no mínimo 7 caracteres");
                form.login.focus;
                return false;
            }
            
        } else {
            alert("Usuário com caracteres inválido! O campo permite apenas letras.")
            form.login.focus;
            return false;
        }
    
        if(form.password.value != ""){
            
            if(form.password.value.length < 5){
                alert("A senha deve conter mais de 6 caracter!");
                form.password.focus;
                return false;
            } 
            
        } else {
            alert("Senha inválida!")
            form.password.focus;
            return false;
        }
}

function alterPassword(form) {
        var passRegex1= /[A-Za-z]/;
        var passRegex2 = /[0-9]/;
        var passRegex3 = /^\w+$/;
    
        if(form.login.value != "" && passRegex1.test(form.login.value)){
            
            if(form.login.value.length < 7){
                alert("O usuário deve conter no mínimo 7 caracteres");
                form.login.focus;
                return false;
            }
            
        } else {
            alert("Usuário com caracteres inválido! O campo permite apenas letras.")
            form.login.focus;
            return false;
        }
        
        if(form.password.value == form.repitPassword.value && form.password.value != ""){
            
            if(form.password.value.length < 6){
                alert("A senha deve conter mais de 6 caracter!");
                form.password.focus;
                return false;
            } 
            
            if(!passRegex1.test(form.password.value) && !passRegex2.test(form.password.value) && passRegex3.test(form.password.value)){
                alert("Senha incorreta");
                form.password.focus();
                return false;
            }
            
        } 
        
        
}

function selectorImage(){
    if(document.getElementById('imagem')){
        document.getElementById('fileImage').value= document.getElementById('imagem').files[0].name;
    }     
}

function checkNome(){
    
    if(form.nome.value.lenght > 50){
        alert("O Nome só pode conter no máximo 150 caracteres!");
        return false;
    } 
    
    if (form.nome.value.lenght > 3){
        alert("O Nome deve conter no mínimo 3 caracteres!");
        return false;
    }
    
}
    
